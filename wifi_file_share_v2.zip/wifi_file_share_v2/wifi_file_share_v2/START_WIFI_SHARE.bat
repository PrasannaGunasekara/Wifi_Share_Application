@echo off
title Wi-Fi File Share v2
cd /d "%~dp0"

echo ========================================
echo          Wi-Fi File Share v2
echo ========================================
echo.

REM Find a supported Python version
py -3.14 --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON=py -3.14
    goto python_found
)

py -3.13 --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON=py -3.13
    goto python_found
)

py -3.12 --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON=py -3.12
    goto python_found
)

echo Python 3.12 or newer was not found.
echo.
echo Please install Python 3.12, 3.13, or 3.14.
echo.
pause
exit /b 1

:python_found

echo Supported Python found.
%PYTHON% --version
echo.

if not exist ".venv\Scripts\python.exe" (
    echo Creating Python environment...
    %PYTHON% -m venv .venv

    if errorlevel 1 (
        echo Failed to create Python environment.
        pause
        exit /b 1
    )

    echo Installing required libraries...
    ".venv\Scripts\python.exe" -m pip install --upgrade pip
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt

    if errorlevel 1 (
        echo Installation failed.
        echo Check your Internet connection.
        pause
        exit /b 1
    )
)

echo.
echo Starting Wi-Fi File Share...
echo.

".venv\Scripts\python.exe" app.py

pause